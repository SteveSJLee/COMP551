python=3.6.5
numpy=1.14.3
pandas=0.23.0
matplotlib=2.2.2


For each question( e.g. Q1, Q2, ...), please run all the cells in order to have correct output
Running a split_data() function in Question 4 can alter the result in the jupyter notebook and the report, since it creates new 80-20 split CSVs

